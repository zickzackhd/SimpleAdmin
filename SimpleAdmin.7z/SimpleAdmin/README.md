# SimpleAdmin

Fivem Admin-Tool

**ZickZackHD'S's modified SimpleMenu Version**

+ Give Player Cars
+ Remove Player Cars
+ Admin Kleidung
+ Give Weapon
+ Godmode
+ Fast run
+ ...


**Requirements**
[pNotify](https://github.com/Nick78111/pNotify)
[NativeUI](included)(https://github.com/FrazzIe/NativeUILua)

**Credits to the original Creator [https://github.com/Thymester/SimpleMenu)**

**For Help at Installation**
FiveM Post: [https://forum.cfx.re/t/simplemenu-ace-permissions-fully-released-lua/324733]

Habt Spass beim Zocken einen schönen Tag wünsch ich euch auch noch :)


Viel Erfolg mit eurem Server


ZickZackHD
