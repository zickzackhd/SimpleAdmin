resource_manifest_version '05cfa83c-a124-4cfa-a768-c24a5811d8f9'

dependency 'NativeUI'
dependency 'es_extended'
client_scripts {

    "@NativeUI/NativeUI.lua",
    "SimpleMenu.lua",
	"client/client.lua",
}

server_scripts {
	'@mysql-async/lib/MySQL.lua',
	'@es_extended/locale.lua',
	"server/main.lua",
    "perms/perms.lua",
}

--client_scripts "SimpleMenu.lua"