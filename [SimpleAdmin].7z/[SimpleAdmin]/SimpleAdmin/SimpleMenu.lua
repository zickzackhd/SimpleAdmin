_menuPool = NativeUI.CreatePool()
mainMenu = NativeUI.CreateMenu("SimpleAdmin", "Made By: ~b~ZickZackHD")
_menuPool:Add(mainMenu)



local allowedToUse = false
Citizen.CreateThread(function()
  TriggerServerEvent("admin:getIsAllowed")
end)

RegisterNetEvent("admin:returnIsAllowed")
AddEventHandler("admin:returnIsAllowed", function(isAllowed)
    allowedToUse = isAllowed
end)

cars = {
  "adder",
  "airbus",
  "airtug",
  "akuma",
  "ambulance",
  "annihilator",
  "armytanker",
  "armytrailer",
  "armytrailer2",
  "asea",
  "asea2",
  "asterope",
  "bagger",
  "baletrailer",
  "baller",
  "baller2",
  "banshee",
  "barracks",
  "barracks2",
  "bati",
  "bati2",
  "benson",
  "bfinjection",
  "biff",
  "bison",
  "bison2",
  "bison3",
  "bjxl",
  "blazer",
  "blazer2",
  "blazer3",
  "blimp",
  "blista",
  "bmx",
  "boattrailer",
  "bobcatxl",
  "bodhi2",
  "boxville",
  "boxville2",
  "boxville3",
  "buccaneer",
  "buffalo",
  "buffalo2",
  "bulldozer",
  "bullet",
  "burrito",
  "burrito2",
  "burrito3",
  "burrito4",
  "burrito5",
  "bus",
  "buzzard",
  "buzzard2",
  "cablecar",
  "caddy",
  "caddy2",
  "camper",
  "carbonizzare",
  "carbonrs",
  "cargobob",
  "cargobob2",
  "cargobob3",
  "cargoplane",
  "cavalcade",
  "cavalcade2",
  "cheetah",
  "coach",
  "cogcabrio",
  "comet2",
  "coquette",
  "cruiser",
  "crusader",
  "cuban800",
  "cutter",
  "daemon",
  "dilettante",
  "dilettante2",
  "dinghy",
  "dinghy2",
  "dloader",
  "docktrailer",
  "docktug",
  "dominator",
  "double",
  "dubsta",
  "dubsta2",
  "dump",
  "dune",
  "dune2",
  "duster",
  "elegy2",
  "emperor",
  "emperor2",
  "emperor3",
  "entityxf",
  "exemplar",
  "f620",
  "faggio2",
  "fbi",
  "fbi2",
  "felon",
  "felon2",
  "feltzer2",
  "firetruk",
  "fixter",
  "flatbed",
  "forklift",
  "fq2",
  "freight",
  "freightcar",
  "freightcont1",
  "freightcont2",
  "freightgrain",
  "freighttrailer",
  "frogger",
  "frogger2",
  "fugitive",
  "fusilade",
  "futo",
  "gauntlet",
  "gburrito",
  "graintrailer",
  "granger",
  "gresley",
  "habanero",
  "handler",
  "hauler",
  "hexer",
  "hotknife",
  "infernus",
  "ingot",
  "intruder",
  "issi2",
  "jackal",
  "jb700",
  "jet",
  "jetmax",
  "journey",
  "khamelion",
  "landstalker",
  "lazer",
  "lguard",
  "luxor",
  "mammatus",
  "manana",
  "marquis",
  "maverick",
  "mesa",
  "mesa2",
  "mesa3",
  "metrotrain",
  "minivan",
  "mixer",
  "mixer2",
  "monroe",
  "mower",
  "mule",
  "mule2",
  "nemesis",
  "ninef",
  "ninef2",
  "oracle",
  "oracle2",
  "packer",
  "packer",
  "patriot",
  "pbus",
  "pcj",
  "penumbra",
  "peyote",
  "phantom",
  "phoenix",
  "picador",
  "police",
  "police2",
  "police3",
  "police4",
  "policeb",
  "policet",
  "polmav",
  "pony",
  "pony2",
  "pounder",
  "prairie",
  "pranger",
  "predator",
  "premier",
  "primo",
  "proptrailer",
  "radi",
  "raketrailer",
  "rancherxl",
  "rancherxl2",
  "rapidgt",
  "rapidgt2",
  "ratloader",
  "rebel",
  "rebel2",
  "regina",
  "rentalbus",
  "rhino",
  "riot",
  "ripley",
  "rocoto",
  "romero",
  "rubble",
  "ruffian",
  "ruiner",
  "rampo",
  "rampo2",
  "sabregt",
  "sadler",
  "sadler2",
  "sanchez",
  "sanchez2",
  "sandking",
  "sandking2",
  "schafter2",
  "schwarzer",
  "scorcher",
  "scrap",
  "seashark",
  "seashark2",
  "seminole",
  "sentinel",
  "sentinel2",
  "serrano",
  "shamal",
  "sheriff",
  "sheriff2",
  "skylift",
  "speedo",
  "speedo2",
  "squalo",
  "stainer",
  "stinger",
  "stingergt",
  "stockade",
  "stockade3",
  "stratum",
  "stretch",
  "stunt",
  "submersible",
  "sultan",
  "suntrap",
  "superd",
  "surano",
  "surfer",
  "surfer2",
  "surge",
  "taco",
  "tailgater",
  "tanker",
  "tankercar",
  "taxi",
  "tiptruck",
  "titan",
  "tornado",
  "tornado2",
  "tornado3",
  "tornado4",
  "tourbus",
  "towtruck",
  "towtruck2",
  "tr2",
  "tr3",
  "tr4",
  "tractor",
  "tractor2",
  "tractor3",
  "trailerlogs",
  "trailers",
  "trailers2",
  "trailers3",
  "trailersmall",
  "trash",
  "trflat",
  "trbike",
  "trbike2",
  "trbike3",
  "tropic",
  "tvtrailer",
  "utillitruck",
  "utillitruck2",
  "utillitruck3",
  "vacca",
  "vader",
  "velum",
  "vlgero",
  "voltic",
  "voodoo2",
  "washington",
  "youga",
  "zion",
  "zion2",
  "ztype",
  }



function Teleport(menu)
  local submenu = _menuPool:AddSubMenu(menu, "Misc Settings", "")
  local tp = NativeUI.CreateItem("~o~Teleport to Waypoint", "Teleport to Waypoint | ~r~NOTE: ~o~May Teleport underground give it a few.")
  submenu:AddItem(tp)
  submenu.OnItemSelect = function(sender, item, index)
    if item == tp then
      local waypoint = GetFirstBlipInfoId(8)
    if DoesBlipExist(waypoint) then
       SetEntityCoords(PlayerPedId(), GetBlipInfoIdCoord(waypoint))
      end
    end
  end
  end


function Cars(menu)
  local submenu = _menuPool:AddSubMenu(menu, "Vehicles Menu", "Sub Menu for Vehicles")
  local carsList = NativeUI.CreateListItem("Spawn Cars", cars, 1)
  local acarsList = NativeUI.CreateListItem("Spawn Addon Cars", acars, 1, "")
  submenu:AddItem(carsList)
  --submenu:AddItem(acarsList)
  submenu.OnListSelect = function(sender, item, index)
      if item == carsList then
        local selectedCar = item:IndexToItem(index)
        spawnCar(selectedCar)
        notify("~b~Car Spawned: "..selectedCar)
      else if item == acarsList then
        local selectedaCar = item:IndexToItem(index)
        spawnCar(selectedaCar)
        notify("~b~Car Spawned: "..selectedaCar)
      end
    end
  end
  local othermenu = _menuPool:AddSubMenu(submenu, "~b~Vehicle Controls")
  local hood = NativeUI.CreateItem("Toggle Vehicle Hood", "Toggles Vehicle's Hood")
  local trunk = NativeUI.CreateItem("Toggle Trunk", "Toggles Vehicle's Trunk")
  local door1 = NativeUI.CreateItem("Toggle Passenger Door", "Opens Front Right Door")
  local door2 = NativeUI.CreateItem("Toggle Driver Door", "Opens Front Left Door")
  local door3 = NativeUI.CreateItem("Toggle Rear Left Door", "Opens Rear Left Door")
  local door4 = NativeUI.CreateItem("Toggle Rear Right Door", "Opens Rear Right Door")
  local engine = NativeUI.CreateItem("Toggle Engine", "Toggles Vehicle's Engine")
  local fixcar = NativeUI.CreateItem("Fix Vehicle", "Fixes Vehicle Ped is in.")
  local cleancar = NativeUI.CreateItem("Clean Vehicle", "Cleans Vehicle Ped is in.")
  local delv = NativeUI.CreateItem("~r~Delete Vehicle", "Deletes Vehicle or use F9")
  submenu:AddItem(fixcar)
  submenu:AddItem(cleancar)
  submenu:AddItem(delv)
  submenu.OnItemSelect = function(sender, item, index)
      if item == fixcar then
        local vehicle = GetVehiclePedIsIn(GetPlayerPed(-1), false)
        SetVehicleEngineHealth(vehicle, 0)
        SetVehicleEngineOn( vehicle, true, true )
        SetVehicleFixed(vehicle)
      else if item == cleancar then
        local vehicle = GetVehiclePedIsIn(GetPlayerPed(-1), false)
        SetVehicleDirtLevel(vehicle, 0)
      else if item == delv then
        local ped = GetPlayerPed( -1 )

    if (DoesEntityExist(ped) and not IsEntityDead(ped)) then 
        local pos = GetEntityCoords(ped)
        if (IsPedSittingInAnyVehicle(ped)) then 
          local vehicle = GetVehiclePedIsIn(ped, false)
          if (GetPedInVehicleSeat(vehicle, -1) == ped) then 
            SetEntityAsMissionEntity(vehicle, true, true )
            deleteCar(vehicle)
            if (DoesEntityExist(vehicle)) then 
              notify("~r~Unable to delete vehicle... Try Again")
            else 
              notify("~g~Vehicle deleted")
            end 
          else 
            notify("~o~You must be in the driver's seat!")
            end 
        else
          local playerPos = GetEntityCoords(ped, 1)
          local inFrontOfPlayer = GetOffsetFromEntityInWorldCoords(ped, 0.0, distanceToCheck, 0.0)
          local vehicle = GetVehicleInDirection(playerPos, inFrontOfPlayer)
          if ( DoesEntityExist(vehicle)) then 
            SetEntityAsMissionEntity(vehicle, true, true)
            deleteCar(vehicle)
            if (DoesEntityExist(vehicle)) then 
              notify("~r~Unable to delete vehicle... Try Again")
            else 
              notify("~g~Vehicle deleted")
            end 
          else 
            notify("~o~Must be in the driver's seat!")
              end
            end 
          end 
        end 
      end
    end
  end
  seats = {-1,0,1,2}
  local seat = NativeUI.CreateSliderItem("Change Seats", seats, 1)
  submenu:AddItem(seat)
  submenu.OnSliderChange = function(sender, item, index)
      if item == seat then
        vehSeat = item:IndexToItem(index)
        local pedsCar = GetVehiclePedIsIn(GetPlayerPed(-1),false)
        SetPedIntoVehicle(PlayerPedId(), pedsCar, vehSeat)
      end
  end
  othermenu:AddItem(engine)
  othermenu:AddItem(door2)
  othermenu:AddItem(door1)
  othermenu:AddItem(door3)
  othermenu:AddItem(door4)
  othermenu:AddItem(hood)
  othermenu:AddItem(trunk)
  othermenu.OnItemSelect = function(sender, item, index)
    if item == engine then
      local vehicle = GetVehiclePedIsIn(PlayerPedId(), false)
    if vehicle ~= nil and vehicle ~= 0 and GetPedInVehicleSeat(vehicle, 0) then
      SetVehicleEngineOn(vehicle, (not GetIsVehicleEngineRunning(vehicle)), false, true)
    end
  else if item == door1 then
    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)
  if veh ~= nil and veh ~= 0 and veh ~= 1 then
    if GetVehicleDoorAngleRatio(veh, 1) > 0 then
        SetVehicleDoorShut(veh, 1, false)
  else
    SetVehicleDoorOpen(veh, 1, false, false)
  end
  end
  else if item == door2 then
  local ped = PlayerPedId()
  local veh = GetVehiclePedIsIn(ped, false)
  if veh ~= nil and veh ~= 0 and veh ~= 1 then
  if GetVehicleDoorAngleRatio(veh, 0) > 0 then
    SetVehicleDoorShut(veh, 0, false)
  else
  SetVehicleDoorOpen(veh, 0, false, false)
  end
  end
  else if item == door3 then
  local ped = PlayerPedId()
  local veh = GetVehiclePedIsIn(ped, false)
  if veh ~= nil and veh ~= 0 and veh ~= 1 then
  if GetVehicleDoorAngleRatio(veh, 2) > 0 then
    SetVehicleDoorShut(veh, 2, false)
  else
  SetVehicleDoorOpen(veh, 2, false, false)
  end
  end
  else if item == door4 then
  local ped = PlayerPedId()
  local veh = GetVehiclePedIsIn(ped, false)
  if veh ~= nil and veh ~= 0 and veh ~= 1 then
  if GetVehicleDoorAngleRatio(veh, 3) > 0 then
    SetVehicleDoorShut(veh, 3, false)
  else
  SetVehicleDoorOpen(veh, 3, false, false)
  end
  end
  else if item == hood then
    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)
  if veh ~= nil and veh ~= 0 and veh ~= 1 then
    if GetVehicleDoorAngleRatio(veh, 4) > 0 then
        SetVehicleDoorShut(veh, 4, false)
  else
    SetVehicleDoorOpen(veh, 4, false, false)
  end
  end
  else if item == trunk then
    local ped = PlayerPedId()
  local veh = GetVehiclePedIsIn(ped, false)
  if veh ~= nil and veh ~= 0 and veh ~= 1 then
    if GetVehicleDoorAngleRatio(veh, 5) > 0 then
        SetVehicleDoorShut(veh, 5, false)
    else
        SetVehicleDoorOpen(veh, 5, false, false)
          end
        end
      end
    end
      end
        end
          end
        end
      end
    end
  end


weapons = {
  "weapon_knife",
  "weapon_knightstick",
  "weapon_hammer",
  "weapon_bat",
  "weapon_crowbar",
  "weapon_golfclub",
  "weapon_pistol",
  "weapon_combatpistol",
  "weapon_appistol",
  "weapon_pistol50",
  "weapon_microsmg",
  "weapon_smg",
  "weapon_assaultsmg",
  "weapon_assaultrifle",
  "weapon_carbinerifle",
  "weapon_advancedrifle",
  "weapon_pumpshotgun",
  "weapon_fireextinguisher",
  "weapon_flare",
  "weapon_snspistol",
  "weapon_heavypistol",
  "weapon_bullpuprifle",
  "weapon_dagger",
  "weapon_vintagepistol",
  "weapon_firework",
  "weapon_flaregun",
  "weapon_marksmanpistol",
  "weapon_knuckle",
  "weapon_hatchet",
  "weapon_switchblade",
  "weapon_revolver",
  "weapon_battleaxe",
  "weapon_minismg",
  "weapon_poolcue",
  "weapon_wrench",
  }

function Weapons(menu)
  local submenu = _menuPool:AddSubMenu(menu, "Weapons Menu", "Sub Menu for Weapons") 
  local gunsList = NativeUI.CreateListItem("Get Weapons", weapons, 1)
    submenu.OnListSelect = function(sender, item, index)  
        if item == gunsList then
            local selectedGun = item:IndexToItem(index)
            giveWeapon(selectedGun)
            notify("Gave Weapon: "..selectedGun)
      end
    end
      local click = NativeUI.CreateItem("~r~Clear Weapon(s)", "Clears Peds Weapons")
      local weapon = NativeUI.CreateItem("~b~Give all Weapons")
      submenu.OnItemSelect = function (sender, item, index)
        if item == click then
          RemoveAllPedWeapons(GetPlayerPed(-1), true)
          notify("~r~Removed All Weapon(s)")
        else if item == weapon then
          giveWeapon("weapon_knife")
          giveWeapon("weapon_knightstick")
          giveWeapon("weapon_hammer")
          giveWeapon("weapon_bat")
          giveWeapon("weapon_crowbar")
          giveWeapon("weapon_golfclub")
          giveWeapon("weapon_pistol")
          giveWeapon("weapon_combatpistol")
          giveWeapon("weapon_appistol")
          giveWeapon("weapon_pistol50")
          giveWeapon("weapon_microsmg")
          giveWeapon("weapon_smg")
          giveWeapon("weapon_assaultsmg")
          giveWeapon("weapon_assaultrifle")
          giveWeapon("weapon_carbinerifle")
          giveWeapon("weapon_advancedrifle")
          giveWeapon("weapon_pumpshotgun")
          giveWeapon("weapon_fireextinguisher")
          giveWeapon("weapon_flare")
          giveWeapon("weapon_snspistol")
          giveWeapon("weapon_heavypistol")
          giveWeapon("weapon_bullpuprifle")
          giveWeapon("weapon_dagger")
          giveWeapon("weapon_vintagepistol")
          giveWeapon("weapon_firework")
          giveWeapon("weapon_flaregun")
          giveWeapon("weapon_marksmanpistol")
          giveWeapon("weapon_knuckle")
          giveWeapon("weapon_hatchet")
          giveWeapon("weapon_switchblade")
          giveWeapon("weapon_revolver")
          giveWeapon("weapon_battleaxe")
          giveWeapon("weapon_minismg")
          giveWeapon("weapon_poolcue")
          giveWeapon("weapon_wrench")
        end
    end
  end
  submenu:AddItem(gunsList)
  submenu:AddItem(weapon)
  submenu:AddItem(click)
  end



function PlayerMenu(menu)
  local submenu = _menuPool:AddSubMenu(menu, "Player Menu", "Sub Menu for Player Related Options")
  local othermenu = _menuPool:AddSubMenu(submenu, "~b~Weapons Menu", "Sub Menu for Weapons") 
  local armour = NativeUI.CreateItem("Get Armour ~w~[~g~On ~w~/~r~ Off~w~]", "Gives Player Ped Armour")
  local heal = NativeUI.CreateItem("Heal Player", "Heals Player Ped")
  local tp = NativeUI.CreateItem("Teleport To Waypoint", "Teleports Ped to Waypoint")
  local nwanted = NativeUI.CreateItem("Remove Wanted", "Removes Player Wanted Level")
  local iwanted = NativeUI.CreateItem("Increase Wanted", "Increases Player Wanted Level")
  local suicide = NativeUI.CreateItem("~r~Commit Suicide", "Kills Player")

  local gunsList = NativeUI.CreateListItem("Get Weapons", weapons, 1)
  othermenu.OnListSelect = function(sender, item, index)  
        if item == gunsList then
            local selectedGun = item:IndexToItem(index)
            giveWeapon(selectedGun)
            notify("Gave Weapon: "..selectedGun)
      end
    end
      local click = NativeUI.CreateItem("~r~Clear Weapon(s)", "Clears Peds Weapons")
      local weapon = NativeUI.CreateItem("~b~Give all Weapons", "")
      othermenu:AddItem(gunsList)
      othermenu:AddItem(weapon)
      othermenu:AddItem(click)
      
      othermenu.OnItemSelect = function (sender, item, index)
        if item == click then
          RemoveAllPedWeapons(GetPlayerPed(-1), true)
          notify("~r~Removed All Weapon(s)")
        else if item == weapon then
          giveWeapon("weapon_knife")
          giveWeapon("weapon_knightstick")
          giveWeapon("weapon_hammer")
          giveWeapon("weapon_bat")
          giveWeapon("weapon_crowbar")
          giveWeapon("weapon_golfclub")
          giveWeapon("weapon_pistol")
          giveWeapon("weapon_combatpistol")
          giveWeapon("weapon_appistol")
          giveWeapon("weapon_pistol50")
          giveWeapon("weapon_microsmg")
          giveWeapon("weapon_smg")
          giveWeapon("weapon_assaultsmg")
          giveWeapon("weapon_assaultrifle")
          giveWeapon("weapon_carbinerifle")
          giveWeapon("weapon_advancedrifle")
          giveWeapon("weapon_pumpshotgun")
          giveWeapon("weapon_fireextinguisher")
          giveWeapon("weapon_flare")
          giveWeapon("weapon_snspistol")
          giveWeapon("weapon_heavypistol")
          giveWeapon("weapon_bullpuprifle")
          giveWeapon("weapon_dagger")
          giveWeapon("weapon_vintagepistol")
          giveWeapon("weapon_firework")
          giveWeapon("weapon_flaregun")
          giveWeapon("weapon_marksmanpistol")
          giveWeapon("weapon_knuckle")
          giveWeapon("weapon_hatchet")
          giveWeapon("weapon_switchblade")
          giveWeapon("weapon_revolver")
          giveWeapon("weapon_battleaxe")
          giveWeapon("weapon_minismg")
          giveWeapon("weapon_poolcue")
          giveWeapon("weapon_wrench")
          notify("~g~Weapons Given")
        end
    end
  end
  end

function Admin(menu)
  local submenu = _menuPool:AddSubMenu(menu, "Admin Menu", "Sub Menu for Admin Related Options")

 local godmode = NativeUI.CreateItem("~r~God Mode ~w~[~g~On~w~ / ~r~Off]", "Gives Player Ped God Mode")
  local changeskin = NativeUI.CreateItem("~g~Admin~w~[~g~On~w~ / ~r~Off]", "Gives Player Admin skin ")
  local gone = NativeUI.CreateItem("~r~Invisibility ~w~[~g~On~w~ / ~r~Off]", "Gives Player Ped Invisibility")
  --local gone2 = NativeUI.CreateItem("~r~Invisible [Off]", "Removes Player Ped Invisibility")
  local fswim = NativeUI.CreateItem("~o~Fast Swim ~w~[~g~On~w~ / ~r~Off]", "Swim Faster")
  local fsprint = NativeUI.CreateItem("~o~Fast Sprint ~w~[~g~On~w~ / ~r~Off]", "Spring Faster")
   submenu:AddItem(changeskin)
  submenu:AddItem(godmode)
  submenu:AddItem(gone)
  submenu:AddItem(fsprint)
  submenu:AddItem(fswim)
  submenu.OnItemSelect = function(sender, item, index)
  if item == godmode then 
    if allowedToUse then
      god = not god
      if god then
	  --test
			SetEntityInvincible(GetPlayerPed(-1), true)
			SetPlayerInvincible(PlayerId(), true)
			SetPedCanRagdoll(GetPlayerPed(-1), false)
			ClearPedBloodDamage(GetPlayerPed(-1))
			ResetPedVisibleDamage(GetPlayerPed(-1))
			ClearPedLastWeaponDamage(GetPlayerPed(-1))
			SetEntityProofs(GetPlayerPed(-1), true, true, true, true, true, true, true, true)
			SetEntityOnlyDamagedByPlayer(GetPlayerPed(-1), false)
			SetEntityCanBeDamaged(GetPlayerPed(-1), false)
	  --test
     
      notify("~g~God Mode On")
    else
	--test
			SetEntityInvincible(GetPlayerPed(-1), false)
			SetPlayerInvincible(PlayerId(), false)
			SetPedCanRagdoll(GetPlayerPed(-1), true)
			ClearPedLastWeaponDamage(GetPlayerPed(-1))
			SetEntityProofs(GetPlayerPed(-1), false, false, false, false, false, false, false, false)
			SetEntityOnlyDamagedByPlayer(GetPlayerPed(-1), true)
			SetEntityCanBeDamaged(GetPlayerPed(-1), true)
	--test
	
      
      notify("~r~God Mode Off")
    end
    else
      notify("~r~You don't have permission")
    end
	end
    if item == changeskin then
      if allowedToUse then
		 
			  

	
        Realskin = not Realskin
        if Realskin then
        local isMale = true
		if savedskin == nil then
		TriggerEvent('skinchanger:getSkin', function(skin)
			--print(json.encode(skin))
			savedskin = skin
		end) 
		end
		TriggerEvent('skinchanger:loadSkin', {
			sex          = 0,
			tshirt_1     = 15,
			torso_1      = 178,
			pants_1      = 77,
			shoes_1      = 55,
			helmet_1     = 92,	
		})

        notify("~g~Admin skin On")
      else
	
			
			
			
       TriggerEvent('skinchanger:loadSkin', savedskin)
	
		
        notify("~r~Admin skin is now Off")
		
      
	   --notify("Skin konnte nicht geladen werden")
	   end
      else
        notify("~r~You don't have permission")
      
	  
	  
	  end
	  end
	
	  
	  
	  end
	if item == gone then 
      if allowedToUse then
        Invisible = not Invisible
        if Invisible then
        SetEntityVisible(GetPlayerPed(-1), false)
        notify("~g~Invisibility is now On")
      else
        SetEntityVisible(GetPlayerPed(-1), true)
        notify("~r~Invisibility is now Off")
      end
      else
        notify("~r~You don't have permission")
      end
	  end
     if item == fswim then
      if allowedToUse then
      fastSwim = not fastSwim
      if fastSwim then
        SetSwimMultiplierForPlayer(PlayerId(), 1.49)
        notify("Fast Swim is now On")
      else
        SetSwimMultiplierForPlayer(PlayerId(), 1.0)
        notify("~r~Fast Swim is now Off")
      end
      else
        notify("~r~You don't have permission") 
      end
	  end
      if item == fsprint then
        if allowedToUse then
        fastSprint = not fastSprint
        if fastSprint then
          SetRunSprintMultiplierForPlayer(PlayerId(), 1.49)
          notify("Fast Sprint is now On")
      else
        SetRunSprintMultiplierForPlayer(PlayerId(), 1.0)
        notify("~r~Fast Sprint is now Off")
      end
      else
        notify("~r~You don't have permission") 
      end
            end
			end
          
        
      
    
 
function Donator(menu)
  local submenu = _menuPool:AddSubMenu(menu, "Donator Menu", "Sub Menu for Donator Related Options")
 --start
 players = {}
	local localplayers = {}
	for _, i in ipairs(GetActivePlayers()) do
		table.insert( localplayers, GetPlayerServerId(i) )
	end
	table.sort(localplayers)
	for i,thePlayer in ipairs(localplayers) do
		table.insert(players,GetPlayerFromServerId(thePlayer))
	end
 --work
 
	 for i,thePlayer in ipairs(players) do
			thisPlayer = _menuPool:AddSubMenu(submenu,"["..GetPlayerServerId(thePlayer).."] "..GetPlayerName(thePlayer),"",true)

			
			-- generate specific menu stuff, dirty but it works for now
			
			
			--givecar
		
				local givecar = _menuPool:AddSubMenu(thisPlayer,"~g~Givecar","",true)
				givecar:SetMenuWidthOffset(menuWidth)
				
				local thisItems = NativeUI.CreateItem("spawnname","put inside hier the spawn name from the car")
				givecar:AddItem(thisItems)
				carspawnname = "nospawnname"
				thisItems:RightLabel(carspawnname)
				thisItems.Activated = function(ParentMenu,SelectedItem)
					DisplayOnscreenKeyboard(1, "FMMC_KEY_TIP8", "", "", "", "", "", 128 + 1)
					
					while UpdateOnscreenKeyboard() ~= 1 and UpdateOnscreenKeyboard() ~= 2 do
						Citizen.Wait( 0 )
					end
					
					local result = GetOnscreenKeyboardResult()
					
					if result and result ~= "" then
					
						carspawnname = result
						thisItems:RightLabel(result) -- this is broken for now
						
						
					else
						carspawnname = "nospawnname"
					end
				end
				
				local thisItem = NativeUI.CreateItem("confirm","Are you shure to give player X the Car?")
				givecar:AddItem(thisItem)
				thisItem.Activated = function(ParentMenu,SelectedItem)
					if carspawnname == "nospawnname" then
					 notify("~r~No Carspawnname set! ")
					else
					--TriggerServerEvent("SimpleAdmin:kickPlayer", GetPlayerServerId( thePlayer ), carlicenseplate)
						RegisterNetEvent("SimpleAdmin:getIsAllowedmanagecar")
						TriggerServerEvent("SimpleAdmin:getIsAllowedmanagecar", GetPlayerServerId( thePlayer ), carspawnname)
						
						notify("~g~Car succesful given! ")
						carspawnname = "nospawnname"
						thisItems:RightLabel(carspawnname) 
					end
					
				
					carspawnname = "nospawnname"
					_menuPool:CloseAllMenus()
					Citizen.Wait(800)
					
					submenu:Visible(true)
				end		
				
			--givecar
			
			--removecar
		
				local removecar = _menuPool:AddSubMenu(thisPlayer,"~r~Removecar","",true)
				removecar:SetMenuWidthOffset(menuWidth)
				
				local SthisItem = NativeUI.CreateItem("carlicenseplate","Kenzeichen mussen mit Lerzeichen angebenen werden. Bsp: BBL 213")
				removecar:AddItem(SthisItem)
				carlicenseplate = "nocarlicenseplate"
				SthisItem:RightLabel(carlicenseplate)
				SthisItem.Activated = function(ParentMenu,SelectedItem)
					DisplayOnscreenKeyboard(1, "FMMC_KEY_TIP8", "", "", "", "", "", 128 + 1)
					
					while UpdateOnscreenKeyboard() ~= 1 and UpdateOnscreenKeyboard() ~= 2 do
						Citizen.Wait( 0 )
					end
					
					local result = GetOnscreenKeyboardResult()
					
					if result and result ~= "" then
					
						carlicenseplate = result
						SthisItem:RightLabel(result) -- this is broken for now
						
					else
						carlicenseplate = "nocarlicenseplate"
					end
				end
				
				local thisItem = NativeUI.CreateItem("confirm","Bitte überprüfe das Kenzeichen erneut bevor du es absendest!")
				removecar:AddItem(thisItem)
				thisItem.Activated = function(ParentMenu,SelectedItem)
					if carlicenseplate == "nocarlicenseplate" then
					 notify("~r~No Carlicenseplate set! ")
					else
					
						TriggerServerEvent("SimpleAdmin:removecar", GetPlayerServerId( thePlayer ), carlicenseplate)
						carlicenseplate = "nocarlicenseplate"
						SthisItem:RightLabel(carlicenseplate) 
						notify("~r~Auto Erfolgreich enfernt!")
					end
					
				
					carlicenseplate = "nocarlicenseplate"
					_menuPool:CloseAllMenus()
					Citizen.Wait(800)
					
					submenu:Visible(true)
				end		
				
			--removecar
		
	 end
 --end
  
 
 
 
        end
      
    
  
function AddMenu_Close(menu)
    local Item = NativeUI.CreateItem("~r~Close Menu", "")
      Item.Activated = function(ParentMenu, SelectedItem)
        mainMenu:Visible(not mainMenu:Visible())
      end
    menu:AddItem(Item)
    end





Donator(mainMenu)
Admin(mainMenu)
PlayerMenu(mainMenu)
Cars(mainMenu)
--Weapons(mainMenu)
Teleport(mainMenu)
AddMenu_Close(mainMenu)
_menuPool:RefreshIndex()
_menuPool:MouseControlsEnabled(false)
_menuPool:ControlDisablingEnabled(false)
_menuPool:RefreshIndex()

Citizen.CreateThread(function()
  while true do
    Citizen.Wait(0)
    _menuPool:ProcessMenus()
    if IsControlJustPressed(1, 166) then
	--stuff
		 --start
	 players = {}
		local localplayers = {}
		for _, i in ipairs(GetActivePlayers()) do
			table.insert( localplayers, GetPlayerServerId(i) )
		end
		table.sort(localplayers)
		for i,thePlayer in ipairs(localplayers) do
			table.insert(players,GetPlayerFromServerId(thePlayer))
		end
	 --work
	--end stuff
        if allowedToUse then
          mainMenu:Visible(not mainMenu:Visible())
        end
      
      end
  end
  end)

--Perm Version of the above!

--[[Citizen.CreateThread(function()
  while true do
      Citizen.Wait(0)
      _menuPool:ProcessMenus()
      if IsControlJustPressed(1, 166) then
      if allowedToUse then
          mainMenu:Visible(not mainMenu:Visible())
end
      end
  end
end)]]

function notify(text)
  SetNotificationTextEntry("STRING")
  AddTextComponentString(text)
  DrawNotification(true, true)
  end
function giveWeapon(hash)
  GiveWeaponToPed(GetPlayerPed(-1), GetHashKey(hash), 999, false, false)
  end
function spawnCar(car)
  local car = GetHashKey(car)

  RequestModel(car)
  while not HasModelLoaded(car) do
  RequestModel(car)
  Citizen.Wait(50)
  end

  local x, y, z = table.unpack(GetEntityCoords(PlayerPedId(), false))
  local vehicle = CreateVehicle(car, x + 2, y + 2, z + 1, GetEntityHeading(PlayerPedId()), true, false)
  SetPedIntoVehicle(PlayerPedId(), vehicle, -1)
    
    SetEntityAsNoLongerNeeded(vehicle)
    SetModelAsNoLongerNeeded(vehicleName)
  end

function loadModel(modelHash)
  local model = GetHashKey(modelHash)
  RequestModel(model)
  while not HasModelLoaded(model) do
    RequestModel(model)
    Citizen.Wait(0)
  end
  SetPlayerModel(localPed, model)
  SetModelAsNoLongerNeeded(model)
  end

function deleteCar( entity )
  Citizen.InvokeNative( 0xEA386986E786A54F, Citizen.PointerValueIntInitialized( entity ) )
  end

function GetVehicleInDirection( coordFrom, coordTo )
  local rayHandle = CastRayPointToPoint( coordFrom.x, coordFrom.y, coordFrom.z, coordTo.x, coordTo.y, coordTo.z, 10, GetPlayerPed( -1 ), 0 )
  local _, _, _, _, vehicle = GetRaycastResult( rayHandle )
  return vehicle
  end

function ShowNotification( text )
  SetNotificationTextEntry( "STRING" )
  AddTextComponentString( text )
  DrawNotification( false, false )
  end
    
  

    

    

  
    
    function ShowNotification(text)
          SetNotificationTextEntry("STRING")
          AddTextComponentString(text)
          DrawNotification(false, false)
      end

    function GetClosePlayer()
        local players = GetPlayers()
        local closestDistance = -1
        local closestPlayer = -1
        local ped = GetPlayerPed(-1)
        local pedCoords = GetEntityCoords(ped, 0)
    
        for index, value in ipairs(players) do
            local target = GetPlayerPed(value)
    
            if target ~= ped then
                local targetCoords = GetEntityCoords(GetPlayerPed(value), 0)
                local distance = Vdist(targetCoords['x'], targetCoords['y'], targetCoords['z'], pedCoords['x'], pedCoords['y'], pedCoords['z'])
    
                if closestDistance == -1 or closestDistance > distance then
                    closestPlayer = value
                    closestDistance = distance
                end
            end
        end
    
        return closestPlayer, closestDistance
    end